from django.contrib import admin
from .models import Category, Good, Application
from django.contrib.admin import AdminSite

AdminSite.site_header = "Интернет-аптеке Long Life"

admin.site.register(Category)
admin.site.register(Good)
admin.site.register(Application)

