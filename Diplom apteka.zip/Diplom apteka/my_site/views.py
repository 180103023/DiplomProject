from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.views.generic.base import View, TemplateResponseMixin
from .models import Category, Good
from django.contrib import messages
from cart.forms import CartAddGoodForm
from .forms import ApplicationForm, UserRegistrationForm

# Регистрация пользователя
class UserRegistrationView(TemplateResponseMixin, View):
    template_name = 'registration/registration.html' 

    def get(self,request):
        registration_form = UserRegistrationForm()
        return self.render_to_response(
            {'registration_form': registration_form})

    def post(self, request):
        registration_form = UserRegistrationForm(request.POST)
        if registration_form.is_valid():
            registration=registration_form.save(commit=False)
            registration.set_password(
                registration_form.cleaned_data['password']
            )
            registration.save()
            authenticate_user = authenticate(
                username=registration_form.cleaned_data['username'],
                password=registration_form.cleaned_data['password']
            )
            login(request, authenticate_user)
            return redirect('my_site:index')
        return self.render_to_response(
            {'registration_form': registration_form})

class IndexView(TemplateResponseMixin, View):
    template_name = 'index.html'

    def get(self, request, *args, **kwargs):
        category = self.kwargs.get('category', None)
        search_text = request.GET.get('search_text', '')
        categories = Category.objects.all()
        goods = Good.objects.all()
        cart_product_form = CartAddGoodForm()
        if category:
            goods = Good.objects.filter(category=category)
        if search_text:
            goods = Good.objects.filter(title__icontains=search_text)
        return self.render_to_response({
            'categories': categories,
            'goods': goods,
            'cart_product_form': cart_product_form
            })


class CreateApplicationView(View):

    def post(self, request):
        form = ApplicationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.add_message(request, messages.INFO, 'Өтінішіңіз қабылданды, жақын араза біздің менеджерлер сізбен хабарласады!.')
            return redirect('my_site:index')
        messages.add_message(request, messages.INFO, 'Қателік кетті. Қайта жіберуіңізді өтінеміз!')
        return redirect('my_site:index')


class GoodDetailView(TemplateResponseMixin, View):
    template_name = 'detail.html'

    def get(self, request, id):
        good = Good.objects.get(id=id)
        cart_product_form = CartAddGoodForm()
        return self.render_to_response({'good': good,
            'cart_product_form': cart_product_form})





