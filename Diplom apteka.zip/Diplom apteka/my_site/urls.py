from django.urls import path
from . import views
app_name = 'my_site'

urlpatterns = [
    path('index/', views.IndexView.as_view(),
     name='index'),
    path('index/<int:category>', views.IndexView.as_view(),
     name='index'),
    path('detail/<int:id>', views.GoodDetailView.as_view(),
     name='good_detail'),
    path('create/application', views.CreateApplicationView.as_view(),
     name='create_application'),
    path('registration', views.UserRegistrationView.as_view(), name='registration'),
]
